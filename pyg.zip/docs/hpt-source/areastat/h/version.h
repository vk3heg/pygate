/* $Id$ */

#ifndef _VERSION_H
#define _VERSION_H

#include "cvsdate.h"

/* basic version number */
#define areastat_VER_MAJOR  1
#define areastat_VER_MINOR  9
#define areastat_VER_PATCH  0
#define areastat_VER_BRANCH BRANCH_CURRENT

extern char      *versionStr;

#endif
