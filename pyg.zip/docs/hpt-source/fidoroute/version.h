#ifndef __FIDOROUTE__VERSION_H
#define __FIDOROUTE__VERSION_H

#define fidoroute_VER_MAJOR  1
#define fidoroute_VER_MINOR  38
#define fidoroute_VER_PATCH  0
#define fidoroute_VER_BRANCH BRANCH_CURRENT

#endif