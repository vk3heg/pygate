/* $Id$ */

#ifndef _VERSION_H
#define _VERSION_H

#include "cvsdate.h"

/* basic version number */
#define bsopack_VER_MAJOR 1
#define bsopack_VER_MINOR 9
#define bsopack_VER_PATCH 0
#define bsopack_VER_BRANCH BRANCH_CURRENT

extern char      *versionStr;

#endif
