#ifndef __UNDELETE_H__
#define __UNDELETE_H__

int undeleteMsgs(s_fidoconfig * config, char * altImportLog);

#endif
