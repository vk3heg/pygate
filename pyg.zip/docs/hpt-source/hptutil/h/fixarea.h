#ifndef __FIXAREA_H__
#define __FIXAREA_H__

int fixArea(s_fidoconfig * config);

#endif
