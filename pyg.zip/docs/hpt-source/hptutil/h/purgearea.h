#ifndef __PURGEAREA_H__
#define __PURGEAREA_H__

void purgeAreas(s_fidoconfig * config);

#endif
