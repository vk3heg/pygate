/* $Id$ */

#ifndef _POST_H
#define _POST_H

void post(int c, unsigned int * n, char * params[]);

#endif
