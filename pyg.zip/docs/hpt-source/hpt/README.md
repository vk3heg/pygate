# hpt
[![Build Status](https://travis-ci.org/huskyproject/hpt.svg?branch=master)](https://travis-ci.org/huskyproject/hpt)
[![Build status](https://ci.appveyor.com/api/projects/status/0kaxqkacvxxiybm5/branch/master?svg=true)](https://ci.appveyor.com/project/dukelsky/hpt/branch/master)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/a48f316649654647a5a832abade6fdae)](https://www.codacy.com/app/dukelsky/hpt?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=huskyproject/hpt&amp;utm_campaign=Badge_Grade)


**HPT** is a FidoNet tosser. It is a part of HUSKY portable fidonet software.

See doc/hpt.* for command reference

See INSTALL for installation instructions.

HPT is a free software, distributed under GPL Licence.
See COPYING file for copying conditions.

See also [The Husky project](https://github.com/huskyproject) and its [homepage](https://huskyproject.github.io/).
