# areafix
[![Build Status](https://travis-ci.org/huskyproject/areafix.svg?branch=master)](https://travis-ci.org/huskyproject/areafix)
[![Build status](https://ci.appveyor.com/api/projects/status/5idj76hxtru7k90p/branch/master?svg=true)](https://ci.appveyor.com/project/dukelsky/areafix/branch/master)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/f2a2a5564bea4ee49f44c20254ac22dd)](https://www.codacy.com/app/dukelsky/areafix?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=huskyproject/areafix&amp;utm_campaign=Badge_Grade)

**Areafix** is a library implementing Areafix and Filefix functionality for [HPT](https://github.com/huskyproject/hpt) and [HTICK](https://github.com/huskyproject/htick) subprojects of the Fidonet software [Husky project](https://github.com/huskyproject)
