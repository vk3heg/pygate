/* $Id$ */

#ifndef SQPACK_VERSION_H
#define SQPACK_VERSION_H

#include "cvsdate.h"
/* basic version number */
#define sqpack_VER_MAJOR  1
#define sqpack_VER_MINOR  9
#define sqpack_VER_PATCH  0
#define sqpack_VER_BRANCH BRANCH_CURRENT

extern char * versionStr;

#endif
