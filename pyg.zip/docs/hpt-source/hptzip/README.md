# hptzip
[![Build Status](https://travis-ci.org/huskyproject/hptzip.svg?branch=master)](https://travis-ci.org/huskyproject/hptzip)
[![Build status](https://ci.appveyor.com/api/projects/status/orxxav6v6w1ortke/branch/master?svg=true)](https://ci.appveyor.com/project/dukelsky/hptzip/branch/master)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/6fc9393f02ec484eb1f1ea7450bc62dc)](https://www.codacy.com/app/dukelsky/hptzip?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=huskyproject/hptzip&amp;utm_campaign=Badge_Grade)

**hptzip** is a built-in zip for [hpt](https://github.com/huskyproject/hpt) (zipInternal)

Uses zlib and minizip

(For win32 zlib is downloaded from http://www.winimage.com/zLibDll/)
