#ifndef SMAPI_VERSION_H
#define SMAPI_VERSION_H

/* basic version number */
#define smapi_VER_MAJOR  2
#define smapi_VER_MINOR  5
#define smapi_VER_PATCH  2
#define smapi_VER_BRANCH BRANCH_CURRENT

#endif
